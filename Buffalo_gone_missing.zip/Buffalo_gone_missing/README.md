# Traveller across the world. (Recreated in Godot)

A faithful recreation of the classic *Super Mario Bros.* (NES) game using the **Godot Engine**.

---

## Tech Stack
- **Engine**: [Godot](https://godotengine.org/)
- **Language**: Godot's GDScript
- **Platform**: Web-Based Deployment

---

## Controls
- **Move Left**: `A` or `Left Arrow`
- **Move Right**: `D` or `Right Arrow`
- **Crouch**: `S` or `Down Arrow`
- **Jump**: `Space Bar`
- **Sprint / Select**: `Shift`
- **Start**: `Enter`

---

Enjoy reliving the classic adventure!

---

## Features
- Faithful recreation of the original *Super Mario Bros.* mechanics.
- Responsive controls and smooth gameplay.

---

## Acknowledgments
This project was developed using the **Godot Engine**, leveraging its powerful scripting capabilities to recreate one of gaming's most iconic titles.
Presented by 
653380187-0 นางสาวกรกนก พฤทธิพันธุ์ KKU
653380321-0 นางสาวกุลนิษฐ์ เตียรวัฒนศิริ KKU
653380207-0 นายพงษ์วรินทร์ แก้วสง่า KKU
653380339-3 นายภูมินทร์ บุญทวี KKU

**CP352203-Computer Game Development 2025**
